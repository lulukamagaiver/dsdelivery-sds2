package com.devsuperior.dsdelivery;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DsdeliveryApplicationTests {

	@Test
	void contextLoads() {
	}

}
