package com.devsuperior.dsdelivery;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DsdeliveryApplication {

	public static void main(String[] args) {
		SpringApplication.run(DsdeliveryApplication.class, args);
	}

}
